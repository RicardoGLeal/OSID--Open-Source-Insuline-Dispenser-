package ModelClass;

/**
 * Created by Wolf Soft on 9/6/2017.
 */

public class CleanerUpModelClass {

    String name;

    public CleanerUpModelClass(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
