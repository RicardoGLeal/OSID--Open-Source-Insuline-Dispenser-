package design.ws.com.cleanupapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ImmediateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_immediate);
    }
}
